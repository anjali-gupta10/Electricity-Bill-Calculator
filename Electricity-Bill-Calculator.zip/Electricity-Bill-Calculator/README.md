# Electricity Bill Calculator (Python 3)

**PS No. 4** – Rungta International Skills University, School of Computer Science and Engineering
B.Tech CSE

## Problem Statement
Calculate an electricity bill from the units consumed using slab-wise rates, add a fixed charge and tax, and print a formatted bill.

| Slab | Rate |
|---|---|
| First 100 units (0–100) | Rs. 3 / unit |
| Next 100 units (101–200) | Rs. 5 / unit |
| Above 200 units | Rs. 8 / unit |
| Fixed charge | Rs. 50 |
| Tax | 5% on (energy + fixed charge) |

**Concepts used:** Conditions (if-elif-else), Operators, Functions

## Project Structure
```
Electricity-Bill-Calculator/
├── electricity_bill.py   # main program (single .py file)
├── README.md             # this file
└── Project_Report.docx   # documentation / report
```

## How to Run
```bash
python electricity_bill.py
```
Enter the consumer name and units consumed when prompted.

## Functions
| Function | Purpose |
|---|---|
| `calculate_energy_charge(units)` | Slab-wise energy charge using if-elif-else |
| `calculate_tax(energy, fixed)` | 5% tax on (energy + fixed) |
| `calculate_total(energy, fixed, tax)` | Total payable amount |
| `get_consumer_name()` | Reads a non-empty name |
| `get_units()` | Reads units; re-asks on negative / non-numeric input |
| `generate_bill(name, units)` | Calculates and prints the formatted bill |

## Test Cases
| # | Input (units) | Expected Output | Result |
|---|---|---|---|
| 1 | 80 | Energy: 240.00 \| Fixed: 50.00 \| Tax: 14.50 → Total Bill: 304.50 | Pass |
| 2 | 100 | Energy: 300.00 \| Fixed: 50.00 \| Tax: 17.50 → Total Bill: 367.50 | Pass |
| 3 | -20, then abc | Invalid units. Enter a non-negative number. | Pass |
| 4 | 250 | Energy: 1200.00 \| Fixed: 50.00 \| Tax: 62.50 → Total Bill: 1312.50 | Pass |

## Sample Output
```
============================================
              ELECTRICITY BILL
============================================
Consumer Name                          Rahul
Units Consumed                            80
--------------------------------------------
Energy Charge (Rs.)                   240.00
Fixed Charge (Rs.)                     50.00
Tax @ 5% (Rs.)                         14.50
--------------------------------------------
TOTAL BILL (Rs.)                      304.50
============================================
Energy: 240.00 | Fixed: 50.00 | Tax: 14.50
Total Bill: 304.50
============================================
```
