"""
Electricity Bill Calculator
---------------------------
PS No. 4 - Rungta International Skills University
Bachelor of Technology - Computer Science and Engineering

Calculates an electricity bill from units consumed using slab-wise rates,
adds a fixed charge and tax, and prints a neatly formatted bill.

Slabs:
    First 100 units  -> Rs. 3 per unit
    Next 100 units   -> Rs. 5 per unit  (101 - 200)
    Above 200 units  -> Rs. 8 per unit
Fixed charge        -> Rs. 50
Tax                 -> 5% on (energy charge + fixed charge)

Concepts used: Conditions (if-elif-else), Operators, Functions
Language: Python 3
"""

# ----------------------------- Constants ----------------------------- #
SLAB1_LIMIT = 100       # first 100 units
SLAB2_LIMIT = 200       # next 100 units (up to 200)
SLAB1_RATE = 3.0        # Rs. per unit
SLAB2_RATE = 5.0        # Rs. per unit
SLAB3_RATE = 8.0        # Rs. per unit
FIXED_CHARGE = 50.0     # Rs.
TAX_RATE = 0.05         # 5%


# ----------------------------- Functions ----------------------------- #
def calculate_energy_charge(units):
    """Return the energy charge for the given units using slab-wise rates."""
    if units <= SLAB1_LIMIT:
        energy = units * SLAB1_RATE
    elif units <= SLAB2_LIMIT:
        energy = (SLAB1_LIMIT * SLAB1_RATE) + (units - SLAB1_LIMIT) * SLAB2_RATE
    else:
        energy = (SLAB1_LIMIT * SLAB1_RATE) \
                 + (SLAB2_LIMIT - SLAB1_LIMIT) * SLAB2_RATE \
                 + (units - SLAB2_LIMIT) * SLAB3_RATE
    return energy


def calculate_tax(energy_charge, fixed_charge=FIXED_CHARGE):
    """Return 5% tax on (energy charge + fixed charge)."""
    return (energy_charge + fixed_charge) * TAX_RATE


def calculate_total(energy_charge, fixed_charge, tax):
    """Return the total payable bill amount."""
    return energy_charge + fixed_charge + tax


def get_consumer_name():
    """Read a non-empty consumer name from the user."""
    while True:
        name = input("Enter consumer name: ").strip()
        if name:
            return name
        print("Name cannot be empty. Please enter a valid name.")


def get_units():
    """Read units consumed; keep asking until a non-negative number is entered."""
    while True:
        value = input("Enter units consumed: ").strip()
        try:
            units = float(value)
        except ValueError:
            print("Invalid units. Enter a non-negative number.")
            continue
        if units < 0:
            print("Invalid units. Enter a non-negative number.")
            continue
        # show whole numbers without .0
        return int(units) if units.is_integer() else units


def generate_bill(name, units):
    """Calculate all charges and print the bill in a neat formatted layout."""
    energy = calculate_energy_charge(units)
    fixed = FIXED_CHARGE
    tax = calculate_tax(energy, fixed)
    total = calculate_total(energy, fixed, tax)

    line = "=" * 44
    dash = "-" * 44
    print()
    print(line)
    print("{:^44}".format("ELECTRICITY BILL"))
    print(line)
    print("{:<26}{:>18}".format("Consumer Name", name))
    print("{:<26}{:>18}".format("Units Consumed", units))
    print(dash)
    print("{:<26}{:>18}".format("Energy Charge (Rs.)", "%.2f" % energy))
    print("{:<26}{:>18}".format("Fixed Charge (Rs.)", "%.2f" % fixed))
    print("{:<26}{:>18}".format("Tax @ 5% (Rs.)", "%.2f" % tax))
    print(dash)
    print("{:<26}{:>18}".format("TOTAL BILL (Rs.)", "%.2f" % total))
    print(line)
    # One-line summary (matches expected output format of the test cases)
    print("Energy: %.2f | Fixed: %.2f | Tax: %.2f" % (energy, fixed, tax))
    print("Total Bill: %.2f" % total)
    print(line)

    return energy, fixed, tax, total


# ------------------------------- Main -------------------------------- #
def main():
    print("*" * 44)
    print("{:^44}".format("ELECTRICITY BILL CALCULATOR"))
    print("*" * 44)
    name = get_consumer_name()
    units = get_units()
    generate_bill(name, units)


if __name__ == "__main__":
    main()
